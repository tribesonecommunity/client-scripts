Last updated: 1/18/2022

Adds a Quake / UT-like announcer to the game!

# Installation
- Unzip to your root Tribes directory.

The sound files should go into `base/sound` and the `announcer.acs.cs` file in `config/modules`.

Some of the sound files included aren't being used, feel free to mix and match what you like. Customization heavily encouraged! :)

Here's a great resource for finding announcer-like sounds: https://www.sounds-resource.com/search/?q=announcer
